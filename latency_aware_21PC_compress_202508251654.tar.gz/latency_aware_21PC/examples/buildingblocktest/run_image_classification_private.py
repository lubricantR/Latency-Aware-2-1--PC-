# coding=utf-8
# Modified by SHAFT's team: Private Text Classification on ImageNet-1k.
# 

import argparse
import logging
import torch

import datasets
import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

from tqdm.auto import tqdm

import transformers
from transformers import AutoConfig, AutoModelForImageClassification

import os
import crypten.communicator as comm

from crypten.mpc.rhyltz import rhy3mul,rhy3waitall1
from crypten.mpc import MPCTensor

import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class MultiHeadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads):
        super(MultiHeadAttention, self).__init__()
        assert embed_dim % num_heads == 0, "embed_dim must be divisible by num_heads"
        
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.d_k = embed_dim // num_heads
        
        # 线性变换层
        self.W_q = nn.Linear(embed_dim, embed_dim)
        self.W_k = nn.Linear(embed_dim, embed_dim)
        self.W_v = nn.Linear(embed_dim, embed_dim)
        self.W_o = nn.Linear(embed_dim, embed_dim)
        
    def scaled_dot_product_attention(self, Q, K, V, mask=None):
        batch_size = Q.size(0)
        # 变换形状为 (batch_size, num_heads, seq_len, d_k)
        Q = Q.view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        K = K.view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        V = V.view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        
        # 计算注意力分数
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)
        
        # 应用掩码（可选）
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        
        # 注意力权重
        attn = F.softmax(scores, dim=-1)
        # 计算输出
        output = torch.matmul(attn, V)
        
        # 恢复形状为 (batch_size, seq_len, embed_dim)
        output = output.transpose(1, 2).contiguous().view(batch_size, -1, self.embed_dim)
        return output
    
    def forward(self, x, mask=None):
        # 输入形状: (batch_size, seq_len, embed_dim)
        # 自注意力: query, key, value 均来自 x
        Q = self.W_q(x)
        K = self.W_k(x)
        V = self.W_v(x)
        
        # 计算多头注意力
        output = self.scaled_dot_product_attention(Q, K, V, mask)
        # 最终线性变换
        output = self.W_o(output)
        # 输出形状: (batch_size, seq_len, embed_dim)
        return output


def main():
    from crypten.rhy3time import flushtimer,r3time
    from crypten.mpc.rhyltz import rhy3waitall1

    if os.environ["RANK"]=='1':
        device = "cuda"
    else:
        device = "cuda"
    
    ct.init()
    rank=int(os.environ["RANK"])
    
    


    
    if False:
        layers = []
        for _ in range(30):
            layers.append(torch.nn.Linear(1024, 1024))
        model = torch.nn.Sequential(*layers);model.eval()
        dummy_input = torch.ones([1024,1024])
        input_enc = ct.cryptensor(dummy_input).to(device)
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('matmul inffering time')


    if False:
        layers = []
        for _ in range(1):
            layers.append(torch.nn.Linear(4096, 1024))

        model = torch.nn.Sequential(*layers);model.eval()
        dummy_input=torch.randn([128,4096])
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        input_enc = ct.cryptensor(dummy_input).to(device)
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('matmul2 inffering time')


    if False:
        layers = []
        for _ in range(30):
            #layers.append(torch.nn.Linear(1024, 1024))
            
            #layers.append(torch.nn.ReLU())
            #layers.append(torch.nn.LayerNorm(1000))
            #layers.append(transformers.pytorch_utils.Conv1D(nf=1000,nx=1000))
            layers.append(torch.nn.GELU(approximate="tanh"))
        dummy_input=torch.randn([1024,1024])
        
        input_enc = ct.cryptensor(dummy_input).to(device)
        model = torch.nn.Sequential(*layers);model.eval()
        
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('gelu inffering time')



    if False:
        layers = []
        for _ in range(30):
            layers.append(torch.nn.ReLU())
            #layers.append(torch.nn.LayerNorm(1000))
            #layers.append(transformers.pytorch_utils.Conv1D(nf=1000,nx=1000))
            
    
        model = torch.nn.Sequential(*layers);model.eval()
        dummy_input=torch.randn([1024,1024])
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        input_enc = ct.cryptensor(dummy_input).to(device)
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('Relu inffering time')

    if False:
        layers = []
        for _ in range(30):
            layers.append(torch.nn.LayerNorm(1024))

        model = torch.nn.Sequential(*layers);model.eval()
        dummy_input=torch.randn([1024,1024])
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        input_enc = ct.cryptensor(dummy_input).to(device)
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('layernorm inffering time')

    if False:
        layers = []
        for _ in range(30):
            layers.append(torch.nn.LayerNorm(256))

        model = torch.nn.Sequential(*layers);model.eval()
        dummy_input=torch.randn([256,256])
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        input_enc = ct.cryptensor(dummy_input).to(device)
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('layernorm2 inffering time')
    
    if False:
        
        model=MultiHeadAttention(1024, 16)
        
        dummy_input=torch.randn([1024,1024])
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        input_enc = ct.cryptensor(torch.randn([1,64,1024])).to(device)
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('mha inffering time')

    if True:
        model=MultiHeadAttention(512, 8)
        dummy_input=torch.randn([1,32,512])
        private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
        input_enc = ct.cryptensor(dummy_input).to(device)
        flushtimer()
        with ct.no_grad():
            private_model(input_enc)     
        rhy3waitall1();r3time('mha2 inffering time')


    


    

'''
    m1=torch.ones(10000)*2;m2=torch.ones(10000)*10
    m1=ct.cryptensor(m1).to(device);    m2=ct.cryptensor(m2).to(device)
    for i in range(200):
        
        z=MPCTensor( rhy3mul(m1,m2))
        if i%100==99:
            rhy3waitall1()
        #z=m1*m2
    rhy3waitall1()
    print(z.get_plain_text()/65536/65536)'''
        

if __name__ == "__main__":
    
    args = parse_args()
    
    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()
'''msg=torch.ones((5))
    if rank==1:
        msg*=5;
        comm.get().send(msg,0)
    else:
        msg=comm.get().recv(msg,1)
    print(f'rank{rank} {msg}')'''  
    
