#!/usr/bin/env python
# coding=utf-8
# Modified by SHAFT's team: Private Text Generation.
#
# Copyright 2018 Google AI, Google Brain and Carnegie Mellon University Authors and the HuggingFace Inc. team.
# Copyright (c) 2018, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Conditional text generation with the auto-regressive models of the library (GPT/GPT-2/CTRL/Transformer-XL/XLNet)"""

import argparse
import inspect
import logging
from typing import Tuple

import torch

import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher
def topn_overlap(a: torch.Tensor, b: torch.Tensor, n: int) -> int:
    """
    计算两个向量的 Top-N 元素中有多少个是相同的（按值排序）。

    Args:
        a (torch.Tensor): 向量 A（1D Tensor）
        b (torch.Tensor): 向量 B（1D Tensor）
        n (int): Top-N 范围

    Returns:
        int: Top-N 元素中相同的元素数量
    """
    if a.ndim != 1 or b.ndim != 1:
        raise ValueError("Input tensors must be 1D")
    if len(a) != len(b):
        raise ValueError("Input tensors must have the same length")
    if n > len(a):
        raise ValueError("n cannot be larger than vector length")

    # 取前 N 个最大值的索引
    topn_a = torch.topk(a, n).indices
    topn_b = torch.topk(b, n).indices

    # 转为 set 做交集
    overlap = set(topn_a.tolist()) & set(topn_b.tolist())
    return len(overlap)
from transformers import (
    AutoTokenizer,
    BloomForCausalLM,
    BloomTokenizerFast,
    CTRLLMHeadModel,
    CTRLTokenizer,
    GenerationMixin,
    GPT2LMHeadModel,
    GPT2Tokenizer,
    GPTJForCausalLM,
    LlamaForCausalLM,
    LlamaTokenizer,
    OpenAIGPTLMHeadModel,
    OpenAIGPTTokenizer,
    OPTForCausalLM,
    TransfoXLLMHeadModel,
    TransfoXLTokenizer,
    XLMTokenizer,
    XLMWithLMHeadModel,
    XLNetLMHeadModel,
    XLNetTokenizer,
    GPTNeoForCausalLM,
)
from transformers.modeling_outputs import CausalLMOutputWithPast


logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

MAX_LENGTH = int(10000)  # Hardcoded max length to avoid infinite loop

MODEL_CLASSES = {
    "gpt2": (GPT2LMHeadModel, GPT2Tokenizer),
    "ctrl": (CTRLLMHeadModel, CTRLTokenizer),
    "openai-gpt": (OpenAIGPTLMHeadModel, OpenAIGPTTokenizer),
    "xlnet": (XLNetLMHeadModel, XLNetTokenizer),
    "transfo-xl": (TransfoXLLMHeadModel, TransfoXLTokenizer),
    "xlm": (XLMWithLMHeadModel, XLMTokenizer),
    "gptj": (GPTJForCausalLM, AutoTokenizer),
    "bloom": (BloomForCausalLM, BloomTokenizerFast),
    "llama": (LlamaForCausalLM, LlamaTokenizer),
    "opt": (OPTForCausalLM, GPT2Tokenizer),
    "gpt-neo": (GPTNeoForCausalLM, GPT2Tokenizer),
}

# Padding text to help Transformer-XL and XLNet with short prompts as proposed by Aman Rusia
# in https://github.com/rusiaaman/XLNet-gen#methodology
# and https://medium.com/@amanrusia/xlnet-speaks-comparison-to-gpt-2-ea1a4e9ba39e
PREFIX = """In 1991, the remains of Russian Tsar Nicholas II and his family
(except for Alexei and Maria) are discovered.
The voice of Nicholas's young son, Tsarevich Alexei Nikolaevich, narrates the
remainder of the story. 1883 Western Siberia,
a young Grigori Rasputin is asked by his father and a group of men to perform magic.
Rasputin has a vision and denounces one of the men as a horse thief. Although his
father initially slaps him for making such an accusation, Rasputin watches as the
man is chased outside and beaten. Twenty years later, Rasputin sees a vision of
the Virgin Mary, prompting him to become a priest. Rasputin quickly becomes famous,
with people, even a bishop, begging for his blessing. <eod> </s> <eos>"""


#
# Functions to prepare models' input
#


def prepare_ctrl_input(args, _, tokenizer, prompt_text):
    if args.temperature > 0.7:
        logger.info("CTRL typically works better with lower temperatures (and lower top_k).")

    encoded_prompt = tokenizer.encode(prompt_text, add_special_tokens=False)
    if not any(encoded_prompt[0] == x for x in tokenizer.control_codes.values()):
        logger.info("WARNING! You are not starting your generation from a control code so you won't get good results")
    return prompt_text


def prepare_xlm_input(args, model, tokenizer, prompt_text):
    # kwargs = {"language": None, "mask_token_id": None}

    # Set the language
    use_lang_emb = hasattr(model.config, "use_lang_emb") and model.config.use_lang_emb
    if hasattr(model.config, "lang2id") and use_lang_emb:
        available_languages = model.config.lang2id.keys()
        if args.xlm_language in available_languages:
            language = args.xlm_language
        else:
            language = None
            while language not in available_languages:
                language = input("Using XLM. Select language in " + str(list(available_languages)) + " >>> ")

        model.config.lang_id = model.config.lang2id[language]
        # kwargs["language"] = tokenizer.lang2id[language]

    # TODO fix mask_token_id setup when configurations will be synchronized between models and tokenizers
    # XLM masked-language modeling (MLM) models need masked token
    # is_xlm_mlm = "mlm" in args.model_name_or_path
    # if is_xlm_mlm:
    #     kwargs["mask_token_id"] = tokenizer.mask_token_id

    return prompt_text


def prepare_xlnet_input(args, _, tokenizer, prompt_text):
    prefix = args.prefix if args.prefix else args.padding_text if args.padding_text else PREFIX
    prompt_text = prefix + prompt_text
    return prompt_text


def prepare_transfoxl_input(args, _, tokenizer, prompt_text):
    prefix = args.prefix if args.prefix else args.padding_text if args.padding_text else PREFIX
    prompt_text = prefix + prompt_text
    return prompt_text


PREPROCESSING_FUNCTIONS = {
    "ctrl": prepare_ctrl_input,
    "xlm": prepare_xlm_input,
    "xlnet": prepare_xlnet_input,
    "transfo-xl": prepare_transfoxl_input,
}


def adjust_length_to_model(length, max_sequence_length):
    if length < 0 and max_sequence_length > 0:
        length = max_sequence_length
    elif 0 < max_sequence_length < length:
        length = max_sequence_length  # No generation bigger than model size
    elif length < 0:
        length = MAX_LENGTH  # avoid infinite loop
    return length


def sparse_model_config(model_config):
    embedding_size = None
    if hasattr(model_config, "hidden_size"):
        embedding_size = model_config.hidden_size
    elif hasattr(model_config, "n_embed"):
        embedding_size = model_config.n_embed
    elif hasattr(model_config, "n_embd"):
        embedding_size = model_config.n_embd

    num_head = None
    if hasattr(model_config, "num_attention_heads"):
        num_head = model_config.num_attention_heads
    elif hasattr(model_config, "n_head"):
        num_head = model_config.n_head

    if embedding_size is None or num_head is None or num_head == 0:
        raise ValueError("Check the model config")

    num_embedding_size_per_head = int(embedding_size / num_head)
    if hasattr(model_config, "n_layer"):
        num_layer = model_config.n_layer
    elif hasattr(model_config, "num_hidden_layers"):
        num_layer = model_config.num_hidden_layers
    else:
        raise ValueError("Number of hidden layers couldn't be determined from the model config")

    return num_layer, num_head, num_embedding_size_per_head


def generate_past_key_values(model, batch_size, seq_len):
    num_block_layers, num_attention_heads, num_embedding_size_per_head = sparse_model_config(model.config)
    if model.config.model_type == "bloom":
        past_key_values = tuple(
            (
                torch.empty(int(num_attention_heads * batch_size), num_embedding_size_per_head, seq_len)
                .to(model.dtype)
                .to(model.device),
                torch.empty(int(num_attention_heads * batch_size), seq_len, num_embedding_size_per_head)
                .to(model.dtype)
                .to(model.device),
            )
            for _ in range(num_block_layers)
        )
    else:
        past_key_values = tuple(
            (
                torch.empty(batch_size, num_attention_heads, seq_len, num_embedding_size_per_head)
                .to(model.dtype)
                .to(model.device),
                torch.empty(batch_size, num_attention_heads, seq_len, num_embedding_size_per_head)
                .to(model.dtype)
                .to(model.device),
            )
            for _ in range(num_block_layers)
        )
    return past_key_values


def prepare_jit_inputs(inputs, model, tokenizer):
    batch_size = len(inputs)
    dummy_input = tokenizer.batch_encode_plus(inputs, return_tensors="pt")
    dummy_input = dummy_input.to(model.device)
    if model.config.use_cache:
        dummy_input["past_key_values"] = generate_past_key_values(model, batch_size, 1)
    dummy_input["attention_mask"] = torch.cat(
        [
            torch.zeros(dummy_input["attention_mask"].shape[0], 1)
            .to(dummy_input["attention_mask"].dtype)
            .to(model.device),
            dummy_input["attention_mask"],
        ],
        -1,
    )
    return dummy_input


class _ModelFallbackWrapper(GenerationMixin):
    __slots__ = ("_optimized", "_default")

    def __init__(self, optimized, default):
        self._optimized = optimized
        self._default = default

    def __call__(self, *args, **kwargs):
        if kwargs["past_key_values"] is None and self._default.config.use_cache:
            kwargs["past_key_values"] = generate_past_key_values(self._default, kwargs["input_ids"].shape[0], 0)
        kwargs.pop("position_ids", None)
        for k in list(kwargs.keys()):
            if kwargs[k] is None or isinstance(kwargs[k], bool):
                kwargs.pop(k)
        outputs = self._optimized(**kwargs)
        lm_logits = outputs[0]
        past_key_values = outputs[1]
        fixed_output = CausalLMOutputWithPast(
            loss=None,
            logits=lm_logits,
            past_key_values=past_key_values,
            hidden_states=None,
            attentions=None,
        )
        return fixed_output

    def __getattr__(self, item):
        return getattr(self._default, item)

    def prepare_inputs_for_generation(
        self, input_ids, past_key_values=None, inputs_embeds=None, use_cache=None, **kwargs
    ):
        return self._default.prepare_inputs_for_generation(
            input_ids, past_key_values=past_key_values, inputs_embeds=inputs_embeds, use_cache=use_cache, **kwargs
        )

    def _reorder_cache(
        self, past_key_values: Tuple[Tuple[torch.Tensor]], beam_idx: torch.Tensor
    ) -> Tuple[Tuple[torch.Tensor]]:
        """
        This function is used to re-order the `past_key_values` cache if [`~PretrainedModel.beam_search`] or
        [`~PretrainedModel.beam_sample`] is called. This is required to match `past_key_values` with the correct
        beam_idx at every generation step.
        """
        return self._default._reorder_cache(past_key_values, beam_idx)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model_type",
        default=None,
        type=str,
        required=True,
        help="Model type selected in the list: " + ", ".join(MODEL_CLASSES.keys()),
    )
    parser.add_argument(
        "--model_name_or_path",
        default=None,
        type=str,
        required=True,
        help="Path to pre-trained model or shortcut name selected in the list: " + ", ".join(MODEL_CLASSES.keys()),
    )
    parser.add_argument(
        "--len_data",
        type=int,
        default=128,
        help="Sequence length of data to run.",
    )
    parser.add_argument(
        "--comp",
        action="store_true",
        help="If passed, estimate computation time (without communication).",
    )
    parser.add_argument("--prompt", type=str, default="")
    parser.add_argument("--length", type=int, default=20)
    parser.add_argument("--stop_token", type=str, default=None, help="Token at which text generation is stopped")

    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="temperature of 1.0 has no effect, lower tend toward greedy sampling",
    )
    parser.add_argument(
        "--repetition_penalty", type=float, default=1.0, help="primarily useful for CTRL model; in that case, use 1.2"
    )
    parser.add_argument("--k", type=int, default=0)
    parser.add_argument("--p", type=float, default=0.9)

    parser.add_argument("--prefix", type=str, default="", help="Text added prior to input.")
    parser.add_argument("--padding_text", type=str, default="", help="Deprecated, the use of `--prefix` is preferred.")
    parser.add_argument("--xlm_language", type=str, default="", help="Optional language when used with the XLM model.")

    parser.add_argument("--seed", type=int, default=42, help="random seed for initialization")
    parser.add_argument(
        "--use_cpu",
        action="store_true",
        help="Whether or not to use cpu. If set to False, " "we will use gpu/npu or mps device if available",
    )
    parser.add_argument("--num_return_sequences", type=int, default=1, help="The number of samples to generate.")
    parser.add_argument(
        "--fp16",
        action="store_true",
        help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit",
    )
    parser.add_argument("--jit", action="store_true", help="Whether or not to use jit trace to accelerate inference")
    args = parser.parse_args()
    return args
from crypten.nn.module import setrhy3device
from crypten import topn_intersection_count
def logits_to_loss(logits, labels, attention_mask=None):
    
    shift_logits = logits[:, :-1, :].contiguous()  # 忽略最后一个 token 的预测
    shift_labels = labels[:, 1:].contiguous()      # 忽略第一个 token
    
    # 如果提供了 attention_mask，相应移位
    if attention_mask is not None:
        shift_attention_mask = attention_mask[:, 1:].contiguous()
        # 将无效 token 的标签设为 -100（CrossEntropyLoss 的忽略索引）
        shift_labels = shift_labels.masked_fill(shift_attention_mask == 0, -100)
    
    # 计算交叉熵损失
    loss_fn = torch.nn.CrossEntropyLoss(reduction='mean', ignore_index=-100)
    loss = loss_fn(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
    
    return loss.item()
def calculate_dataset_perplexity( model, tokenizer,device,max_length=64):
    from datasets import load_dataset
    import math
    #dataset = load_dataset("wikitext", "wikitext-2-v1", split="test")
    dataset = load_dataset("ptb_text_only", "penn_treebank", split="test")
    total_loss = 0.0
    total_tokens = 0
    
    for example in dataset:
        text = example["sentence"].strip()
        if not text:  # 跳过空文本
            continue
        encodings = tokenizer(text, return_tensors="pt", max_length=max_length, truncation=True)
        input_ids = encodings.input_ids.to(device)
        input_enc = ct.cryptensor(input_ids).to(device)
        
        
        with torch.no_grad():
            outputs = model(input_enc)
            outputs=outputs.get_plain_text()
            loss=logits_to_loss(outputs, input_ids)
            

            
            if loss is not None and not math.isnan(loss):  # 确保损失有效
                total_loss += loss * input_ids.size(1)
                total_tokens += input_ids.size(1)
            print('loss',loss,total_loss / (total_tokens+0.001))
    
    if total_tokens == 0:
        return float("inf")  # 防止除零
    avg_loss = total_loss / total_tokens
    print('totalloss',avg_loss)
    return avg_loss
import math
def tensor_inv_sqrt(self, eps=1e-8):
    return 1.0 / (self + eps).sqrt()
def tensor_gelu(self,approximate=' '):
    coeff = math.sqrt(2 / math.pi)
    return 0.5 * self * (1 + torch.tanh(coeff * (self + 0.044715 * self.pow(3))))
def identity_forward(
        self,
        hidden_states,
        layer_past=None,
        attention_mask=None,
        head_mask=None,
        encoder_hidden_states=None,
        encoder_attention_mask=None,
        use_cache=False,
        output_attentions=False
    ):
        #return hidden_states
        # GPT2Block 返回 tuple(hidden_states, present, attention)
        outputs = (hidden_states,)
        if use_cache:
            outputs += (None,)  # dummy present
        if output_attentions:
            outputs += (None,)  # dummy attention weights
        return outputs if len(outputs) > 1 else outputs[0]
class CustomGPT2Model(torch.nn.Module):
    def __init__(self, model):
        super(CustomGPT2Model, self).__init__()
        # 获取 GPT2 的预训练配置
        self.model = model
        self.transformer = model.transformer  # 使用模型中的 transformer 部分
        self.lm_head = model.lm_head  # 使用模型中的 lm_head

        # 去掉嵌入层
        self.wte = self.transformer.wte
        self.wpe = self.transformer.wpe

        # 保持剩余层
        self.ln_f = self.transformer.ln_f
        self.drop = self.transformer.drop
        self.h = self.transformer.h

    def forward(self, input_ids, attention_mask=None):
        # 重新计算词嵌入
        token_embeds = self.transformer.wte(input_ids)  # [1, seq_len, hidden_dim]
        position_ids = torch.arange(0, input_ids.size(1), dtype=torch.long).unsqueeze(0).to('cuda:1')
        position_embeds = self.transformer.wpe(position_ids)  # [1, seq_len, hidden_dim]
        input_embeddings = token_embeds + position_embeds
        
        # 通过 Dropout 层
        embeddings = self.drop(input_embeddings)

        # 通过 Transformer 层计算
        hidden_states = embeddings
        for block in self.h:
            hidden_states = block(hidden_states, attention_mask=attention_mask)[0]

        # 通过 LayerNorm 层
        hidden_states = self.ln_f(hidden_states)

        # 最终通过 lm_head 生成 logits
        logits = self.lm_head(hidden_states)
        import code
        #code.interact(local=locals())
        return logits


def main():
    torch.Tensor.inv_sqrt = tensor_inv_sqrt
    torch.Tensor.gelu = tensor_gelu
    import os
    from crypten import topn_intersection_count
    if os.environ["RANK"]=='1':
        device = "cuda:1"
    else:
        device = "cuda:1"
    setrhy3device(device)
    args = parse_args()

    logger.warning(f"device: {device}, 16-bits inference: {args.fp16}")

    if args.seed is not None:
        torch.manual_seed(args.seed)

    # Initialize the model and tokenizer
    try:
        args.model_type = args.model_type.lower()
        model_class, tokenizer_class = MODEL_CLASSES[args.model_type]
    except KeyError:
        raise KeyError("the model {} you specified is not supported. You are welcome to add it and open a PR :)")

    tokenizer = tokenizer_class.from_pretrained(args.model_name_or_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = model_class.from_pretrained(args.model_name_or_path)

    # Set the model to the right device
    model.to(device)
    
    if args.fp16:
        model.half()
    max_seq_length = getattr(model.config, "max_position_embeddings", 0)
    args.length = adjust_length_to_model(args.length, max_sequence_length=max_seq_length)
    logger.info(args)

    prompt_text = "test" * args.len_data

    # Different models need different input formatting and/or extra arguments
    requires_preprocessing = args.model_type in PREPROCESSING_FUNCTIONS.keys()
    if requires_preprocessing:
        prepare_input = PREPROCESSING_FUNCTIONS.get(args.model_type)
        preprocessed_prompt_text = prepare_input(args, model, tokenizer, prompt_text)

        if model.__class__.__name__ in ["TransfoXLLMHeadModel"]:
            tokenizer_kwargs = {"add_space_before_punct_symbol": True}
        else:
            tokenizer_kwargs = {}

        encoded_prompt = tokenizer.encode(
            preprocessed_prompt_text, add_special_tokens=False, return_tensors="pt", **tokenizer_kwargs
        )
    else:
        prefix = args.prefix if args.prefix else args.padding_text
        encoded_prompt = tokenizer.encode(prefix + prompt_text, add_special_tokens=False, return_tensors="pt")
    encoded_prompt = encoded_prompt.to(device)

    if encoded_prompt.size()[-1] == 0:
        input_ids = None
    else:
        input_ids = encoded_prompt

    if args.jit:
        jit_input_texts = ["enable jit"]
        jit_inputs = prepare_jit_inputs(jit_input_texts, model, tokenizer)
        torch._C._jit_set_texpr_fuser_enabled(False)
        model.config.return_dict = False
        if hasattr(model, "forward"):
            sig = inspect.signature(model.forward)
        else:
            sig = inspect.signature(model.__call__)
        jit_inputs = tuple(jit_inputs[key] for key in sig.parameters if jit_inputs.get(key, None) is not None)
        traced_model = torch.jit.trace(model, jit_inputs, strict=False)
        traced_model = torch.jit.freeze(traced_model.eval())
        traced_model(*jit_inputs)
        traced_model(*jit_inputs)

        model = _ModelFallbackWrapper(traced_model, model)

    # convert the Hugging Face's NewGELUActivation() to the equivalent torch.nn.GELU(approximate="tanh")
    

    torch.nn.Identity.forward = identity_forward
    for i in range (len(model.transformer.h)):
        model.transformer.h[i].mlp.act = torch.nn.GELU(approximate="tanh")
        #model.transformer.h[i].mlp.act = torch.nn.ReLU()
        #model.transformer.h[i] = torch.nn.Identity()
    #model.transformer.h = model.transformer.h[:1]
    
    from crypten import rhy3nodes, rhy3computednodes
    rhy3nodes=set();rhy3computednodes=set()
    '''with torch.no_grad():
        import os
        
        if os.environ["RANK"] == '0':
            pres=model(input_ids)
            print('********plain result',pres)
    import code
    code.interact(local=locals())
    return'''
    import os
    
    
    ct.init()
    inputtrace=model.dummy_inputs["input_ids"].to(device)
    print(model)

    omodel=model
    token_embeds = omodel.transformer.wte(input_ids)  # [1, seq_len, hidden_dim]
    position_ids = torch.arange(0, input_ids.size(1), dtype=torch.long).unsqueeze(0).to(device)
    position_embeds = omodel.transformer.wpe(position_ids)  # [1, seq_len, hidden_dim]
    input_embeddings = token_embeds + position_embeds

    
    #model=torch.nn.Sequential(model.transformer.drop,model.transformer.ln_f,model.lm_head) #
    model=CustomGPT2Model(model).to(device)
    #model=model.transformer.h[0]
    model.eval()
    #model_enc = ct.nn.from_pytorch(model,input_embeddings).encrypt().to(device)
    #input_enc = ct.cryptensor(input_embeddings).to(device)
    model_enc = ct.nn.from_pytorch(model,input_ids).encrypt().to(device)
    input_enc = ct.cryptensor(input_ids).to(device)
    presinput=input_ids
    calculate_dataset_perplexity(model_enc,tokenizer,device)
    '''
    import transformers
    layers = []
    for _ in range(1):
        #layers.append(torch.nn.Linear(1000, 1000))
        #layers.append(torch.nn.Dropout(p=0.9,inplace=False))
        #layers.append(torch.nn.ReLU())
        #layers.append(torch.nn.LayerNorm(1000))
        #layers.append(transformers.pytorch_utils.Conv1D(nf=1000,nx=1000))
        layers.append(torch.nn.GELU(approximate="tanh"))
        
          # 或 GELU, LeakyReLU 等
    model = torch.nn.Sequential(*layers)
    accipt=torch.randn((1,1000))/10
    model_enc=ct.nn.from_pytorch(
        model,
        torch.ones((1,1000))).encrypt().to(device)
    input_enc = ct.cryptensor(accipt.to(device))'''
    with torch.no_grad():
        if os.environ["RANK"] == '0':
            pres=model(presinput)
            print('********plain result',pres)
    #print(f'modeldev {model_enc.device} inputdev {input_enc.device}')
    from crypten.rhy3time import flushtimer,r3time
    from crypten.mpc.rhyltz import rhy3waitall1
    import os
    flushtimer()
    with ct.no_grad():
        cres=model_enc(input_enc).get_plain_text()
        cipt=input_enc.get_plain_text()
    r3time('inffering time')
    rhy3waitall1()
    import os
        
    if os.environ["RANK"] == '0':
        
        import code
        
        code.interact(local={**globals(), **locals()})
    return
    return


if __name__ == "__main__":
    args = parse_args()
    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()




