#!/bin/bash

# 进程本地网络限制脚本（仅限制带宽和延迟）
# 使用方法: limit_local_process.sh <带宽限制(Kbps)> <延迟(ms)> -- <命令>

# 默认限制值
BANDWIDTH_LIMIT=100        # 默认100Kbps
DELAY=50                   # 默认50ms
INTERFACE="lo"             # 本地回环接口
CGROUP_NAME="net_limit_lo"
MARK="0x1"                 # iptables标记值
CLASS_ID="1:100"           # tc分类ID

# 检查权限
if [ "$(id -u)" -ne 0 ]; then
    echo "请使用root权限运行此脚本"
    exit 1
fi

# 检查必要的命令
for cmd in tc iptables; do
    if ! command -v $cmd &> /dev/null; then
        echo "错误: 需要安装$cmd命令"
        exit 1
    fi
done

# 解析参数
parse_args() {
    # 重置变量
    BANDWIDTH_LIMIT=""
    DELAY=""
    CMD_ARGS=()
    
    # 检查是否有参数
    if [ $# -eq 0 ]; then
        echo "错误: 未提供任何参数"
        echo "用法: $0 <带宽限制(Kbps)> <延迟(ms)> -- <命令>"
        exit 1
    fi
    
    # 解析参数
    found_separator=0
    for arg in "$@"; do
        if [ "$arg" = "--" ]; then
            found_separator=1
            continue
        fi
        
        if [ $found_separator -eq 0 ]; then
            # 处理带宽和延迟参数
            if [ -z "$BANDWIDTH_LIMIT" ]; then
                BANDWIDTH_LIMIT="$arg"
            elif [ -z "$DELAY" ]; then
                DELAY="$arg"
            else
                echo "错误: 过多的参数在 -- 之前"
                echo "用法: $0 <带宽限制(Kbps)> <延迟(ms)> -- <命令>"
                exit 1
            fi
        else
            # 处理命令参数
            CMD_ARGS+=("$arg")
        fi
    done
    
    # 检查是否找到分隔符
    if [ $found_separator -eq 0 ]; then
        echo "错误: 未找到 -- 分隔符"
        echo "用法: $0 <带宽限制(Kbps)> <延迟(ms)> -- <命令>"
        exit 1
    fi
    
    # 检查命令是否存在
    if [ ${#CMD_ARGS[@]} -eq 0 ]; then
        echo "错误: 未指定要执行的命令"
        echo "用法: $0 <带宽限制(Kbps)> <延迟(ms)> -- <命令>"
        exit 1
    fi
}

parse_args "$@"

# 验证参数有效性
if [ -z "$BANDWIDTH_LIMIT" ]; then
    echo "错误: 未指定带宽限制"
    exit 1
fi

if ! [[ "$BANDWIDTH_LIMIT" =~ ^[0-9]+$ ]]; then
    echo "错误: 带宽限制必须是数字"
    exit 1
fi

if [ -z "$DELAY" ]; then
    echo "错误: 未指定延迟"
    exit 1
fi

if ! [[ "$DELAY" =~ ^[0-9]+$ ]]; then
    echo "错误: 延迟必须是数字"
    exit 1
fi

echo "参数解析完成:"
echo "带宽限制: ${BANDWIDTH_LIMIT}Kbps"
echo "延迟: ${DELAY}ms"
echo "命令: ${CMD_ARGS[*]}"

# 启用lo接口转发
sysctl -w net.ipv4.conf.lo.forwarding=1
sysctl -w net.ipv4.conf.all.route_localnet=1

# 检查cgroups版本
CGROUP_VERSION=$(stat -fc %T /sys/fs/cgroup)
echo "检测到的cgroups版本: $CGROUP_VERSION"

# 创建cgroups控制组（兼容v1和v2）
if [ "$CGROUP_VERSION" = "cgroup2fs" ]; then
    # 使用cgroups v2
    CGROUP_PATH="/sys/fs/cgroup/$CGROUP_NAME"
    mkdir -p "$CGROUP_PATH"
    echo 1 > "$CGROUP_PATH/cgroup.procs" || { echo "创建cgroup失败"; exit 1; }
    echo "使用cgroups v2: $CGROUP_PATH"
else
    # 使用cgroups v1
    cgcreate -g net_cls,net_prio:$CGROUP_NAME || { echo "创建cgroup失败，请确保cgroups v1已挂载"; exit 1; }
    echo $((0x10000 + $(echo $CLASS_ID | cut -d: -f2))) > /sys/fs/cgroup/net_cls/$CGROUP_NAME/net_cls.classid
    echo "使用cgroups v1: $CGROUP_NAME"
fi

# 配置tc（仅设置带宽和延迟）
echo "配置TC规则..."
tc qdisc add dev $INTERFACE root handle 1: htb default 10 || { echo "添加根队列失败"; exit 1; }
tc class add dev $INTERFACE parent 1: classid 1:1 htb rate ${BANDWIDTH_LIMIT}kbit || { echo "添加主类失败"; exit 1; }
tc class add dev $INTERFACE parent 1:1 classid $CLASS_ID htb rate ${BANDWIDTH_LIMIT}kbit ceil ${BANDWIDTH_LIMIT}kbit || { echo "添加限制类失败"; exit 1; }

# 添加延迟（仅延迟，不添加其他网络损伤）
echo "添加网络延迟..."
if [ "$DELAY" -gt 0 ]; then
    tc qdisc add dev $INTERFACE parent $CLASS_ID handle 10: netem delay ${DELAY}ms || { echo "添加延迟失败"; exit 1; }
else
    # 如果延迟为0，则不添加netem模块
    tc qdisc add dev $INTERFACE parent $CLASS_ID handle 10: pfifo || { echo "添加默认队列失败"; exit 1; }
fi

# 设置iptables规则
echo "配置iptables规则..."
if [ "$CGROUP_VERSION" = "cgroup2fs" ]; then
    iptables -t mangle -A OUTPUT -m cgroup --path $CGROUP_NAME -j MARK --set-mark $MARK || { echo "添加OUTPUT规则失败"; exit 1; }
else
    iptables -t mangle -A OUTPUT -m cgroup --cgroup $((0x10000 + $(echo $CLASS_ID | cut -d: -f2))) -j MARK --set-mark $MARK || { echo "添加OUTPUT规则失败"; exit 1; }
fi

iptables -t mangle -A PREROUTING -i $INTERFACE -m mark --mark $MARK -j CONNMARK --set-mark $MARK || { echo "添加PREROUTING规则失败"; exit 1; }
iptables -t mangle -A OUTPUT -o $INTERFACE -m connmark --mark $MARK -j MARK --set-mark $MARK || { echo "添加OUTPUT(connmark)规则失败"; exit 1; }

# 将标记的流量导向tc分类
echo "将标记流量导向TC分类..."
tc filter add dev $INTERFACE parent 1: protocol ip handle $MARK fw classid $CLASS_ID || { echo "添加过滤器失败"; exit 1; }

# 启动命令并获取PID
echo "启动命令并限制本地网络..."
echo "接口: $INTERFACE"
echo "带宽限制: ${BANDWIDTH_LIMIT}Kbps"
echo "延迟: ${DELAY}ms"
echo "执行命令: ${CMD_ARGS[*]}"

"${CMD_ARGS[@]}" &
PID=$!
echo "进程PID: $PID"

# 将进程添加到cgroup
echo "将进程添加到cgroup..."
if [ "$CGROUP_VERSION" = "cgroup2fs" ]; then
    echo $PID > "$CGROUP_PATH/cgroup.procs" || { echo "添加进程到cgroup失败"; exit 1; }
else
    echo $PID > /sys/fs/cgroup/net_cls/$CGROUP_NAME/tasks || { echo "添加进程到cgroup失败"; exit 1; }
fi

# 清理函数
cleanup() {
    echo "清理资源..."
    # 移除iptables规则
    if [ "$CGROUP_VERSION" = "cgroup2fs" ]; then
        iptables -t mangle -D OUTPUT -m cgroup --path $CGROUP_NAME -j MARK --set-mark $MARK 2>/dev/null
    else
        iptables -t mangle -D OUTPUT -m cgroup --cgroup $((0x10000 + $(echo $CLASS_ID | cut -d: -f2))) -j MARK --set-mark $MARK 2>/dev/null
    fi
    
    iptables -t mangle -D PREROUTING -i $INTERFACE -m mark --mark $MARK -j CONNMARK --set-mark $MARK 2>/dev/null
    iptables -t mangle -D OUTPUT -o $INTERFACE -m connmark --mark $MARK -j MARK --set-mark $MARK 2>/dev/null
    
    # 移除tc规则
    tc qdisc del dev $INTERFACE parent $CLASS_ID handle 10: 2>/dev/null
    tc class del dev $INTERFACE classid $CLASS_ID 2>/dev/null
    tc class del dev $INTERFACE classid 1:1 2>/dev/null
    tc qdisc del dev $INTERFACE root 2>/dev/null
    
    # 删除cgroup
    if [ "$CGROUP_VERSION" = "cgroup2fs" ]; then
        # 递归清理cgroup v2
        for subtree in $(ls "$CGROUP_PATH" 2>/dev/null); do
            if [ -d "$CGROUP_PATH/$subtree" ]; then
                echo 0 > "$CGROUP_PATH/$subtree/cgroup.procs" 2>/dev/null
            fi
        done
        echo 0 > "$CGROUP_PATH/cgroup.procs" 2>/dev/null
        rmdir "$CGROUP_PATH" 2>/dev/null
    else
        cgdelete -r net_cls,net_prio:$CGROUP_NAME 2>/dev/null
    fi
    
    # 恢复sysctl设置
    sysctl -w net.ipv4.conf.lo.forwarding=0
    sysctl -w net.ipv4.conf.all.route_localnet=0
    
    exit
}

# 设置信号处理
trap cleanup SIGINT SIGTERM EXIT

# 等待进程结束
wait $PID