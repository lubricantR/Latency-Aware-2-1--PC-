import torch
import time

# 设置矩阵大小
size = 10000

# 创建两个随机矩阵
torch.manual_seed(0)
A_cpu = torch.randn(size, size, dtype=torch.float64)
B_cpu = torch.randn(size, size, dtype=torch.float64)
#A_cpu = torch.randint(-100, 100, (size, size), dtype=torch.int32)
#B_cpu = torch.randint(-100, 100, (size, size), dtype=torch.int32)


# ---------------- CPU 预热 ----------------
# 运行一次乘法以加载库和优化路径
#_ = torch.mm(A_cpu, B_cpu)

# ---------------- CPU 测试 ----------------
cfun=A_cpu
start_cpu = time.time()
#C_cpu = torch.mm(A_cpu, B_cpu)
#cfun=(cfun<-0.5)*0+((cfun>=-0.5)*(cfun<0.5))*(cfun+0.5)+(cfun>=0.5)*1
cfun=torch.sigmoid(cfun)
end_cpu = time.time()
print(f"CPU 时间: {end_cpu - start_cpu:.4f} 秒")

# ---------------- GPU 测试 ----------------
if torch.cuda.is_available():
    # 将数据拷贝到 GPU
    A_gpu = A_cpu.to('cuda')
    B_gpu = B_cpu.to('cuda')

    # GPU 预热（运行几次确保稳定）
    for _ in range(3):
        _ = torch.mm(A_gpu, B_gpu)
    torch.cuda.synchronize()

    # 正式测试
    start_gpu = time.time()
    C_gpu = torch.mm(A_gpu, B_gpu)
    torch.cuda.synchronize()
    end_gpu = time.time()
    print(f"GPU 时间: {end_gpu - start_gpu:.4f} 秒")
else:
    print("未检测到 GPU，跳过 GPU 测试。")

