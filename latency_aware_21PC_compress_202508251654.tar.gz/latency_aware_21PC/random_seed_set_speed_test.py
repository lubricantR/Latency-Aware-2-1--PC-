import torch
import time

# 设置矩阵大小
size = 10

# 创建两个随机矩阵
torch.manual_seed(0)


# 创建一个 CPU 上的生成器
g_cpu = torch.Generator()
g_cpu.manual_seed(1234)

# 创建一个 CUDA 上的生成器
g_cuda = torch.Generator(device='cuda')
g_cuda.manual_seed(1234)

# 使用生成器生成随机数



# ---------------- CPU 测试 ----------------
start_cpu = time.time()
rand_tensor = torch.randn((size, int(size*2.5)), generator=g_cpu)
end_cpu = time.time()
print(f"CPU 时间: {end_cpu - start_cpu:.4f} 秒",rand_tensor)

# ---------------- GPU 测试 ----------------
if torch.cuda.is_available():


    start_gpu = time.time()
    rand_tensor = torch.rand((size, int(size*2.5)), generator=g_cuda,device='cuda')
    torch.cuda.synchronize()
    end_gpu = time.time()
    print(f"GPU 时间: {end_gpu - start_gpu:.4f} 秒",rand_tensor)
else:
    print("未检测到 GPU，跳过 GPU 测试。")

