from .cuda_tensor import CUDALongTensor


__all__ = ["CUDALongTensor"]
