import torch
from typing import Tuple
import torch.distributed as dist
from crypten import communicator as comm
from .provider.teep_provider import teep_request
from .rhyrand import random_int_tensor
from  crypten.mpc.primitives.arithmetic import ArithmeticSharedTensor


def pack_bits(bits: torch.Tensor) -> Tuple[torch.Tensor, int]:
    """
    将一个包含 0 和 1 的一维 uint8 张量 bits 打包成 uint8 类型的张量，
    每 8 个比特组成一个字节。
    返回 (packed, orig_len)，其中 orig_len 是 bits 原始长度，用于解包时去除 padding。
    """
    bits = bits.to(torch.uint8).flatten()
    orig_len = bits.numel()
    padding = (8 - orig_len % 8) % 8
    if padding > 0:
        bits = torch.cat([
            bits,
            torch.zeros(padding, dtype=bits.dtype, device=bits.device)
        ], dim=0)
    bits = bits.view(-1, 8)
    weights = 2 ** torch.arange(7, -1, -1, dtype=bits.dtype, device=bits.device)
    packed = (bits * weights).sum(dim=1).to(torch.uint8)
    return packed, orig_len

def unpack_bits(packed: torch.Tensor, orig_len: int) -> torch.Tensor:
    """
    将 pack_bits 生成的 uint8 张量 unpack 回 0/1 张量，并截取回原始长度 orig_len。
    """
    packed = packed.to(torch.uint8).flatten()
    # 用 bitwise 方式展开
    shifts = torch.arange(7, -1, -1, device=packed.device)
    bits = ((packed.unsqueeze(1).bitwise_right_shift(shifts) & 1)
            .to(torch.uint8))
    bits = bits.view(-1)
    if bits.numel() > orig_len:
        bits = bits[:orig_len]
    return bits

def pack_tensor64(x: torch.Tensor, i: int) -> Tuple[torch.Tensor, int, torch.Size]:
    """
    从 int64 张量 x 中提取每个元素第 i 位比特，打包并返回：
      - packed: uint8 张量，每个元素是一字节（8-bit）
      - orig_len: 提取的总比特个数，用于解包时去除 padding
      - shape:   原始张量 x.shape，用于解包后的 reshape
    """
    # 提取第 i 位
    bits = torch.bitwise_and(torch.bitwise_right_shift(x, i), 1).to(torch.uint8)
    packed, orig_len = pack_bits(bits)
    return packed, orig_len, x.shape

def unpack_tensor64(packed: torch.Tensor,
                    orig_len: int,
                    shape: torch.Size) -> torch.Tensor:
    """
    将 pack_tensor64 的输出还原成与原始 x 相同形状的比特张量（0/1 uint8）。
    """
    bits = unpack_bits(packed, orig_len)
    return bits.view(shape)

from crypten.rhy3time import *

def rhy3teemulbit1(shx,shy):
        sendrank=0;
        if cfg.r3fourth==1:
            sendrank=3
        #print('p1s',i)
        with r3namedtime('p1 msb gen rand'):
            v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01).to(shx.device)
            tx1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
            ty1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
            tu1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        with r3namedtime('p1 msb cal dxdy'):
            dx1=shx^tx1;dy1=shy^ty1;
            w1=dist.isend(dx1.cpu(),sendrank);waitlist.append(w1)
            w2=dist.isend(dy1.cpu(),sendrank);waitlist.append(w2)
        with r3namedtime('p1 msb cal z1'):
            z1=(dx1.to(shy.device)&shy)^ (shx&dy1.to(shy.device))^tu1.to(shy.device)^v.to(shy.device)
        #w1.wait();w2.wait();
        #print('p1e',i)
        return z1;
def rhy3teemulbit0(shx,shy):
    recvrank=1;
    if cfg.r3fourth==1:
        recvrank=3
    with r3namedtime('p0 msb gen rand'):
        v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01)
    w1=dist.isend(shx.cpu(),2)
    w2=dist.isend(shy.cpu(),2)
    from crypten import r3fourthrecords

    with r3namedtime('p0 msb recv dx1dy1u0'):
        u0=torch.zeros_like(shx,device='cpu');dx1=torch.zeros_like(shx,device='cpu');dy1=torch.zeros_like(shx,device='cpu')
        dist.recv(dx1,recvrank)
        dist.recv(dy1,recvrank)
        if cfg.r3fourthrecording==1:
            r3fourthrecords.append([dx1.shape,dx1.dtype])
            r3fourthrecords.append([dy1.shape,dy1.dtype])

    with r3namedtime('p0 wait tee'):
        w1.wait();w2.wait();
        dist.recv(u0,2)
    with r3namedtime('p0 cal z0'):
        z0=(dx1.to(shy.device)&shy)^ (shx&dy1.to(shy.device))^u0.to(shy.device)^v.to(shy.device)
    
    #print('p0e',i)
    return z0;

        
def rhy3ltz(x):
    
    if hasattr(x, "tensor"):
        x = x.tensor()
    sendrank=0;
    if cfg.r3fourth==1:
        sendrank=3
    recvrank=1;
    if cfg.r3fourth==1:
        recvrank=3

    shift = torch.iinfo(torch.long).bits - 1
    if comm.get().get_rank()==1:
        
        device=x.device
        
        c, orig_len, shape = pack_tensor64(x, i=0)
        c*=0
        zero=torch.zeros_like(c)
        with r3namedtime('p1 msb',0):
            
            #print('p1running',(c))
            for i in range(shift-1):
                packed, orig_len, shape = pack_tensor64(x, i=i)
                #print(f'p1 no{i} {packed}')
                shxiyi=rhy3teemulbit1(packed,zero);
                shcixiaddyi=rhy3teemulbit1(packed,c);
                c=shxiyi^shcixiaddyi

            packed, orig_len, shape = pack_tensor64(x, i=i)
            c=c^packed
        with r3namedtime('p1 ba2a',0):
            a1=torch.ones_like(x);b1=unpack_tensor64(c, orig_len, shape);
            ta1=random_int_tensor(a1.shape,a1.dtype,comm.get().gseed1).to(device)
            tb1=random_int_tensor(b1.shape,b1.dtype,comm.get().gseed1).to(device)
            u1=random_int_tensor(a1.shape,a1.dtype,comm.get().gseed1).to(device)
            v=random_int_tensor(a1.shape,a1.dtype,comm.get().gseed01).to(device)
            dtab=(b1-tb1)&1;dtaa=a1-ta1;
            senda=((-1)**b1)*dtaa
            waitlist.append( dist.isend(dtab.cpu(),sendrank))
            waitlist.append(dist.isend(senda.cpu(),sendrank))
            z1=b1*dtaa+dtab*ta1+(-1)**dtab*u1-v
        '''
        
        w1=dist.isend(c.cpu(),0)
        otherc=torch.zeros_like(c,device='cpu')
        dist.recv(otherc,0)
        shmsbxor= unpack_tensor64(c^otherc.to(c.device), orig_len, shape)
        w1.wait()'''
        #print('p1 ans',shmsbxor)
        #print('r3ltz return',z1.shape)
        return z1
    if  comm.get().get_rank()==0:
        device=x.device
        c, orig_len, shape = pack_tensor64(x, i=0)
        c*=0
        zero=torch.zeros_like(c)
        teep_request("teerhy3ltz",x.device,c.numel(),x.shape)
        with r3namedtime('p0 msb',0):
            #print('p0running',(c))
            for i in range(shift-1):
                packed, orig_len, shape = pack_tensor64(x, i=i)
                #print(f'p0 no{i} {packed}')
                shxiyi=rhy3teemulbit0(zero,packed);
                shcixiaddyi=rhy3teemulbit0(packed,c);
                c=shxiyi^shcixiaddyi
            packed, orig_len, shape = pack_tensor64(x, i=i)
            c=c^packed

        with r3namedtime('p0 ba2a',0):
            a0=torch.zeros_like(x);b0=unpack_tensor64(c, orig_len, shape);
            dtab=torch.zeros_like(b0,device='cpu');u0=torch.zeros_like(a0,device='cpu')
            neg1b1dtaa=torch.zeros_like(a0,device='cpu')
            dist.send(b0.cpu(),2);dist.send(a0.cpu(),2)

            dist.recv(dtab,recvrank);dist.recv(neg1b1dtaa,recvrank);
            from crypten import r3fourthrecords
            if cfg.r3fourthrecording==1:
                r3fourthrecords.append([dtab.shape,dtab.dtype])
                r3fourthrecords.append([neg1b1dtaa.shape,neg1b1dtaa.dtype])

            dist.recv(u0,2)
            dtab=dtab.to(device);neg1b1dtaa=neg1b1dtaa.to(device);u0=u0.to(device);
            v=random_int_tensor(a0.shape,a0.dtype,comm.get().gseed01).to(device)
            z0=b0*neg1b1dtaa+dtab*a0+((-1)**dtab)*u0+v
        '''
        w1= dist.isend(c.cpu(),1)
        otherc=torch.zeros_like(c,device='cpu')
        dist.recv(otherc,1)
        shmsbxor= unpack_tensor64(c^otherc.to(c.device), orig_len, shape)
        w1.wait()'''
        #print('p0 ans',shmsbxor.dtype)
        #print('r3ltz return',z0.shape)
        return z0

waitlist=[]
def rhy3waitall1():
    global waitlist
    for i in waitlist:
        i.wait()
    waitlist=[]

def rhy3teemuladditive1(shx,shy):
        v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01).to(shx.device)
        #print('p1 gen v',v,v.dtype)
        tx1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        ty1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        tu1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        dx1=shx+tx1;dy1=shy+ty1;
        
        waitlist.append( dist.isend(dx1.cpu(),0))
        waitlist.append( dist.isend(dy1.cpu(),0))
        
        z1=(dx1*shy)+ (shx*dy1)+tu1-v
        return z1;

def rhy3teemuladditive0(shx,shy):
        v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01).to(shx.device)
        #print('p0 gen v',v,v.dtype)
        
        dist.send(shx.cpu(),2);
        dist.send(shy.cpu(),2)
        u0=torch.zeros_like(shx,device='cpu');dx1=torch.zeros_like(shx,device='cpu');dy1=torch.zeros_like(shx,device='cpu')
        
        dist.recv(u0,2)
        
        dist.recv(dx1,1)
        dist.recv(dy1,1)
        
        z0=(dx1.to(shx.device)*shy)+ (shx*dy1.to(shx.device))+u0.to(shx.device)+v
        
        return z0;

def rhy3mul(x,w):
    x=x.share;w=w.share
    if hasattr(x, "tensor"):
        x = x.tensor()
    if hasattr(w, "tensor"):
        w = w.tensor()
    shift = torch.iinfo(torch.long).bits - 1
    
    if comm.get().get_rank()==1:
        #print('p1running')
        #tsend=torch.randn(3);dist.send(tsend,0);print('tsend',tsend)
        
        return rhy3teemuladditive1(x,w)
    if  comm.get().get_rank()==0:
        
        
        teep_request("teerhy3mul",x.device,x.shape)
        #tsend=torch.ones(3);dist.recv(tsend,1);print('p0gettsend',tsend)
        
        return rhy3teemuladditive0(x,w)


def rhy3teetripleadditive1(shx,shy,op,*args, **kwargs):
    with r3namedtime('p1 generate tx1 ty1'):
        tx1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        ty1=random_int_tensor(shy.shape,shy.dtype,comm.get().gseed1).to(shy.device)
    
    dx1=shx+tx1;dy1=shy+ty1;
    if cfg.r3fourth==0:
        waitlist.append( dist.isend(dx1.contiguous().cpu(),0))
        waitlist.append( dist.isend(dy1.contiguous().cpu(),0))
    else:
        #print('p1send',dx1.shape)
        #print('p1send',dy1.shape)
        waitlist.append( dist.isend(dx1.contiguous().cpu(),3))
        waitlist.append( dist.isend(dy1.contiguous().cpu(),3))
    with r3namedtime('p1 triple mul'):
        z1=getattr(torch, op)(dx1,shy,*args, **kwargs)+ getattr(torch, op)(shx,dy1,*args, **kwargs)

    with r3namedtime('p1 generate v tu1'): 
        v=random_int_tensor(z1.shape,z1.dtype,comm.get().gseed01).to(z1.device)
            #print('p1 gen v',v,v.dtype)
        tu1=random_int_tensor(z1.shape,z1.dtype,comm.get().gseed1).to(z1.device)
    
    z1=z1+tu1-v
    #print('p1finish')
    return z1;
from crypten.config import cfg
def rhy3teetripleadditive0(shx,shy,op,*args, **kwargs):
        #input()
        from crypten import r3fourthrecords
        with r3namedtime('p0 contiguous'):
            shx=shx.contiguous();shy=shy.contiguous()
        
        
        if cfg.r3fourth==0:
            dx1=torch.empty_like(shx,device='cpu');dy1=torch.empty_like(shy,device='cpu')
            hrdx1=dist.irecv(dx1.data,1);    hrdy1=dist.irecv(dy1.data,1)
        else:
            dx1=torch.empty_like(shx,device='cpu');dy1=torch.empty_like(shy,device='cpu')
            hrdx1=dist.irecv(dx1.data,3);    hrdy1=dist.irecv(dy1.data,3)

        if cfg.r3fourthrecording==1:
            r3fourthrecords.append([dx1.shape,dx1.dtype])
            r3fourthrecords.append([dy1.shape,dy1.dtype])
        
        virtualx=torch.empty_like(shx.data,device='meta');virtualy=torch.empty_like(shy.data,device='meta');
        virtualz=getattr(torch, op)(virtualx,virtualy,*args, **kwargs)
        with r3namedtime('p0 send x,y'):
            with r3namedtime('p0 send x,y tocpu'):
                sshx=shx.cpu();sshy=shy.cpu()
            with r3namedtime('p0 send x,y send'):
                dist.send(sshx,2);
                dist.send(sshy,2)
        
        
        
        with r3namedtime('p0 gen v'):
            v=random_int_tensor(virtualz.shape,virtualz.dtype,comm.get().gseed01).to(shx.device)
        from crypten import r3fourth_queue
        with r3namedtime('p0 recv dx,dy'):
            if cfg.r3fourth==0:
                hrdx1.wait();hrdy1.wait()
            else:
                #print('getting s')
                hrdx1.wait();#dx1=r3fourth_queue.get()
                #print('getting m')
                hrdy1.wait()#dy1=r3fourth_queue.get()
                #print('getting e')
            #dx1=shx.clone().cpu();dy1=shy.clone().cpu()
            #dx1=torch.empty_like(shx,device='cpu');dy1=torch.empty_like(shy,device='cpu')
            #dist.recv(dx1.data,1);    dist.recv(dy1.data,1)
        with r3namedtime('p0 recv u0'):
            u0=torch.empty(virtualz.shape,device='cpu',dtype=shx.dtype)
            hru0=dist.irecv(u0.data,2)
        with r3namedtime('p0 triple mul'):
            z0=getattr(torch, op)(dx1.to(shx.device),shy,*args, **kwargs)   + getattr(torch, op)(shx,dy1.to(shx.device),*args, **kwargs)

        
        with r3namedtime('p0 recv u0'):
            hru0.wait();
        z0=z0+u0.to(z0.device)+v
        
        return z0;

def rhy3triple(x,y,op,*args, **kwargs):
    #print('rhy3triple args',args,kwargs)
    x=x.share;y=y.share
    
    '''if hasattr(x, "tensor"):
        x = x.tensor()
    if hasattr(w, "tensor"):
        w = w.tensor()'''
    
    if comm.get().get_rank()==1:
        #print('p1running')
        #tsend=torch.randn(3);dist.send(tsend,0);print('tsend',tsend)
        
        ans=rhy3teetripleadditive1(x,y,op,*args, **kwargs)
    if  comm.get().get_rank()==0:
        
        
        teep_request("teerhy3triple",x.device,x.shape,y.shape,op,*args, **kwargs)
        
        ans= rhy3teetripleadditive0(x,y,op,*args, **kwargs)
        #v=random_int_tensor(x.shape,x.dtype,comm.get().gseed01).to(x.device)
    return ans



def rhy3sin(x,*args, **kwargs):
    x=x.share;
    if hasattr(x, "tensor"):
        x = x.tensor()
    
    T=256;pie=3.141592653589793238;
    k=2*pie/T
    ik=int(65536/k)
    x=x*ik//65536
    if comm.get().get_rank()==1:
        tx=random_int_tensor(x.shape,x.dtype,comm.get().gseed1).to(x.device)
        
    
        dx1=x+tx;
        if cfg.r3fourth==0:
            waitlist.append( dist.isend(dx1.contiguous().cpu(),0))
        else:
            waitlist.append( dist.isend(dx1.contiguous().cpu(),3))
        
        v=random_int_tensor(x.shape,x.dtype,comm.get().gseed01).to(x.device)
        u=random_int_tensor(x.shape,x.dtype,comm.get().gseed1).to(x.device)
        
        uv=u+v
        fuv=(torch.sin(uv*k/65536.0)*65536).to(x.dtype);guv=(torch.cos(uv*k/65536.0)*65536).to(x.dtype)
        zero=torch.zeros_like(x)
        s2=rhy3teetripleadditive1(zero,guv,"mul",*args, **kwargs)
        s1= rhy3teetripleadditive1(fuv,zero,"mul",*args, **kwargs)
        return s1+s2
       
        


    if  comm.get().get_rank()==0:
        teep_request("teerhy3sin",x.device,x.shape)
        if cfg.r3fourth==0:
            dx1=torch.empty_like(x,device='cpu');
            hrdx1=dist.irecv(dx1.data,1);    
        else:
            dx1=torch.empty_like(x,device='cpu');
            hrdx1=dist.irecv(dx1.data,3);    
        if cfg.r3fourthrecording==1:
            r3fourthrecords.append([dx1.shape,dx1.dtype])
        
        sx=x.cpu();
        dist.send(sx,2);
        hrdx1.wait()
        u0=torch.empty_like(x,device='cpu'); dist.recv(u0,2)
        xuv=u0.to(x.device)+dx1.to(x.device)
        #print(xuv)
        fxuv=(torch.sin(xuv*k/65536.0)*65536).to(x.dtype);gxuv=(torch.cos(xuv*k/65536.0)*65536).to(x.dtype)
        zero=torch.zeros_like(x,dtype=x.dtype)
        teep_request("teerhy3triple",x.device,x.shape,x.shape,op='mul',*args, **kwargs)
        s1= rhy3teetripleadditive0(fxuv,zero,"mul",*args, **kwargs)
        teep_request("teerhy3triple",x.device,x.shape,x.shape,op='mul',*args, **kwargs)
        s2=rhy3teetripleadditive0(zero,gxuv,"mul",*args, **kwargs)
        return s1+s2
        

















