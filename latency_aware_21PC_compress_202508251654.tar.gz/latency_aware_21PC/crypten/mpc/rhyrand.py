import torch
def random_int_tensor(shape, dtype=torch.int32, generator=None):
    return torch.ones(shape,dtype=dtype)*0
    info = torch.iinfo(dtype)
    return torch.randint(info.min, info.max, shape, dtype=dtype, generator=generator)*0