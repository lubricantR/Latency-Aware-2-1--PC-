#!/usr/bin/env python3

# Copyright (c) Facebook, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import logging

import crypten
import crypten.communicator as comm
import torch
import torch.distributed as dist
from crypten.common.rng import generate_kbit_random_tensor, generate_random_ring_element
from crypten.common.util import count_wraps
from crypten.mpc.primitives import ArithmeticSharedTensor, BinarySharedTensor

from .provider import TupleProvider

from crypten.mpc.rhyrand import random_int_tensor

TEEP_FUNCTIONS = ["additive", "square", "binary", "wraps", "B2A"]
from crypten.rhy3time import *
def teep_request(func_name, device, *args, **kwargs):
    if device is not None:
        device = str(device)
    message = {
        "function": func_name,
        "device": device,
        "args": args,
        "kwargs": kwargs,
    }
    ttp_rank=2
    #print('teep request',message)
    comm.get().send_obj(message, ttp_rank, comm.get().ttp_group)

    #size = comm.get().recv_obj(ttp_rank, comm.get().ttp_group)
    #result = torch.empty(size, dtype=torch.long, device=device)
    #comm.get().broadcast(result, ttp_rank, comm.get().ttp_group)

    return 
def rhy3teemulbit2(shzero):
    #print('tee x1s',shzero.shape)
    shape=shzero.shape;dtype=shzero.dtype
    with r3namedtime('tee msb gen rand'):
        tx1=random_int_tensor(shape,dtype,comm.get().gseed1)
        ty1=random_int_tensor(shape,dtype,comm.get().gseed1)
        tu1=random_int_tensor(shape,dtype,comm.get().gseed1)
    with r3namedtime('tee msb recv x0y0'):
        x0=torch.zeros_like(shzero);dist.recv(x0,0)
        y0=torch.zeros_like(shzero);dist.recv(y0,0)
    with r3namedtime('tee msb cal u0'):
        u0=(x0^tx1)&(y0^ty1)^tu1
    with r3namedtime('tee msb send u0'):
        dist.send(u0,0)
    
    return
def rhy3teemuladditive2(shzero):
    #print('tee s',shzero.shape)
    shape=shzero.shape;dtype=shzero.dtype
    tx1=random_int_tensor(shape,dtype,comm.get().gseed1)
    ty1=random_int_tensor(shape,dtype,comm.get().gseed1)
    tu1=random_int_tensor(shape,dtype,comm.get().gseed1)
    
    x0=torch.zeros_like(shzero);dist.recv(x0,0)
    #print('teep get x0',x0)
    y0=torch.zeros_like(shzero);dist.recv(y0,0)
    #print('teep get y0',y0)
    u0=(x0+tx1)*(y0+ty1)-tu1

    dist.send(u0,0)
    #print('tee e',u0)
    return
def rhy3teetripleadditive2(x0shape,y0shape,op,*args, **kwargs):
    #print('tee s',shzero.shape)
    dtype=torch.long
    x0=torch.empty(x0shape,dtype=dtype);
    y0=torch.empty(y0shape,dtype=dtype);
    hrx0=dist.irecv(x0,0)
    hry0=dist.irecv(y0,0)
    with r3namedtime('tee generate tx1 ty1'):
        tx1=random_int_tensor(x0shape,dtype,comm.get().gseed1)
        ty1=random_int_tensor(y0shape,dtype,comm.get().gseed1)
    
    
    hrx0.wait();hry0.wait()
    #print('teep get x0',x0)
    
    #print('teep get y0',y0)
    with r3namedtime('tee triple mul'):
        u0=getattr(torch, op)((x0+tx1),(y0+ty1),*args, **kwargs)
    with r3namedtime('tee gen tu1'):
        tu1=random_int_tensor(u0.shape,u0.dtype,comm.get().gseed1)
    u0-=tu1;
    dist.send(u0,0)
    #print('tee e',u0)
    return
def rhy3teesin2(x0shape,*args, **kwargs):
    dtype=torch.long
    x0=torch.empty(x0shape,dtype=dtype);
    hrx0=dist.irecv(x0,0)
    
    with r3namedtime('teesin generate tx u'):
        tx=random_int_tensor(x0shape,dtype,comm.get().gseed1)
        tu=random_int_tensor(x0shape,dtype,comm.get().gseed1)
    
    hrx0.wait();

    dist.send(x0-tx-tu,0)

    return
class TEEPServer:
    TERMINATE = -1

    def __init__(self):
        """Initializes a Trusted Third Party server that receives requests"""
        # Initialize connection
        crypten.init()
        self.ttp_group = comm.get().ttp_group
        #self.comm_group = comm.get().ttp_comm_group
        self.device = "cpu"
        #self._setup_generators()
        ttp_rank = comm.get().get_ttp_rank()
        
        logging.info("TEEPServer Initialized")
        print('TEE at rank ',ttp_rank)
        
        try:
            while True:
                # Wait for next request from client
                message = comm.get().recv_obj(0,self.ttp_group)
                logging.info("TEEP Message received: %s" % message)
                #print('teep get',message)
                if message == "terminate":
                    logging.info("TTPServer shutting down.")
                    return

                function = message["function"]
                device=message["device"]
                args = message["args"]
                kwargs = message["kwargs"]

                self.device = device
                
                result = getattr(self, function)(*args, **kwargs)

                #comm.get().send_obj(result.size(), 0, self.ttp_group)
                #comm.get().broadcast(result, ttp_rank, self.comm_group)
        except RuntimeError as err:
            r3timeprintall()
            logging.info("Encountered Runtime error. TTPServer shutting down:")
            logging.info(f"{err}")

    

    

    def teerhy3ltz(self,size,xshape,*args, **kwargs):
        c=torch.zeros(size,dtype=torch.uint8)
        shift = torch.iinfo(torch.long).bits - 1
        #print('tee ltz invoke')
        for i in range(2*(shift-1)):
            rhy3teemulbit2(c);
        b0=torch.zeros(xshape,dtype=torch.uint8);
        a0=torch.zeros(xshape,dtype=torch.long);
        dist.recv(b0,0);dist.recv(a0,0);

        ta1=random_int_tensor(a0.shape,a0.dtype,comm.get().gseed1)
        tb1=random_int_tensor(b0.shape,b0.dtype,comm.get().gseed1)
        u1=random_int_tensor(a0.shape,a0.dtype,comm.get().gseed1)

        dist.send(((b0+tb1)&1)*(a0+ta1)-u1,0)

    def teerhy3mul(self,shape,*args, **kwargs):
        #print('tee invoke')
        c=torch.zeros(shape,dtype=torch.long)
        #print(c.device)
        shift = torch.iinfo(torch.long).bits - 1
        rhy3teemuladditive2(c)
    def teerhy3triple(self,x0shape,y0shape,op ,*args, **kwargs):
        rhy3teetripleadditive2(x0shape,y0shape,op,*args, **kwargs)
    def teerhy3sin(self,x0shape,*args,**kwargs):
        rhy3teesin2(x0shape,*args,**kwargs)

    def additive(self, size0, size1, op, *args, **kwargs):

        # Add all shares of `a` and `b` to get plaintext `a` and `b`
        #a = self._get_additive_PRSS(size0)
        #b = self._get_additive_PRSS(size1)

        c = getattr(torch, op)(a, b, *args, **kwargs)

        # Subtract all other shares of `c` from plaintext value of `c` to get `c0`
        c0 = c - self._get_additive_PRSS(c.size(), remove_rank=True)
        return c0

    def square(self, size):
        # Add all shares of `r` to get plaintext `r`
        r = self._get_additive_PRSS(size)
        r2 = r.mul(r)
        return r2 - self._get_additive_PRSS(size, remove_rank=True)

    def binary(self, size0, size1):
        # xor all shares of `a` and `b` to get plaintext `a` and `b`
        a = self._get_binary_PRSS(size0)
        b = self._get_binary_PRSS(size1)

        c = a & b

        # xor all other shares of `c` from plaintext value of `c` to get `c0`
        c0 = c ^ self._get_binary_PRSS(c.size(), remove_rank=True)
        return c0

    def wraps(self, size):
        r = [generate_random_ring_element(size, generator=g) for g in self.generators]
        theta_r = count_wraps(r)

        return theta_r - self._get_additive_PRSS(size, remove_rank=True)

    def B2A(self, size):
        rB = self._get_binary_PRSS(size, bitlength=1)

        # Subtract all other shares of `rA` from plaintext value of `rA`
        rA = rB - self._get_additive_PRSS(size, remove_rank=True)

        return rA
